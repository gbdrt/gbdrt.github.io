from __future__ import annotations
from typing import *

import os
import shutil
import hashlib
from datetime import datetime

# git init

git_root_dir = ".minigit"


def git_init(repo: str):
    git_path = os.path.join(repo, git_root_dir)
    if not os.path.exists(git_path):
        os.mkdir(git_path)
        os.mkdir(os.path.join(git_path, "objects"))
        os.mkdir(os.path.join(git_path, "refs"))
        os.mkdir(os.path.join(git_path, "refs", "heads"))
        head_path = os.path.join(git_path, "refs", "heads", "main")
        with open(os.path.join(git_path, "HEAD"), "w") as f:
            print("main", file=f)
        with open(head_path, "w") as f:
            pass
        with open(os.path.join(git_path, "index"), "w"):
            pass


def find_repo() -> str:
    def _find(path):
        if git_root_dir in os.listdir(path):
            return path
        else:
            return _find(os.path.join(path, ".."))

    return _find(".")


# Blobs, trees, commits

## Blobs


def hash_object(repo: str, fmt: str, data: str) -> str:
    content = "TODO"
    sha = "TODO"
    path = os.path.join(repo, git_root_dir, "objects", sha)
    if not os.path.exists(path):
        with open(path, "w") as f:
            print(content, file=f)
    return sha


def load_object(repo: str, sha: str) -> Dict[str, str]:
    path = os.path.join(repo, git_root_dir, "objects", sha)
    with open(path, "r") as f:
        raw = f.read()
        fmt = "TODO"
        data = "TODO"
        return {"format": fmt, "data": data}


def load_blob(repo: str, sha: str) -> str:
    blob_obj = load_object(repo, sha)
    assert blob_obj["format"] == "blob"
    return blob_obj["data"]


## Objets git


def serialize_git_object(d: Dict[str, str]) -> str:
    pass


def deserialize_git_object(s: str) -> Dict[str, str]:
    pass


def load_git_object(repo: str, sha: str, format: str) -> Dict[str, str]:
    pass


## Tree


class Tree:
    def __init__(self, name: str, path: str = ""):
        self.name = name.strip()
        self.children: Set[Tree] = set()

    def get_child(self, name: str) -> Optional[Tree]:
        for c in self.children:
            if c.name == name:
                return c
        return None

    def __eq__(self, tree: object) -> bool:
        if isinstance(tree, Tree):
            return self.name.__eq__(tree.name)
        return False

    def __hash__(self) -> int:
        return self.name.__hash__()

    def __str__(self) -> str:
        if not self.children:
            return self.name
        else:
            children = ", ".join([str(x) for x in self.children])
            return f"{self.name} : [{children}]"


def tree_add_loc(tree: Tree, loc: List[str]):
    pass


def tree_from_sha(repo: str, name: str, sha: str) -> Tree:
    pass


def hash_tree(repo: str, index: Tree) -> str:
    def _hash(tree, path):
        data = {}
        for c in tree.children:
            cpath = os.path.join(path, c.name)
            if c.children:
                sha = _hash(c, cpath)
            else:
                with open(os.path.join(repo, cpath), "r") as f:
                    sha = hash_object(repo, "blob", f.read())
            data[sha] = c.name
        return hash_object(repo, "tree", serialize_git_object(data))

    return _hash(index, "")


## Commits


def hash_commit(
    repo: str, author: str, msg: str, tree_sha: str, parent_sha: str
) -> str:
    pass


# git branch


def get_branch(repo: str) -> str:
    head_path = os.path.join(repo, git_root_dir, "HEAD")
    with open(head_path, "r") as f:
        return f.read().strip()


def set_branch(repo: str, branch: str):
    head_path = os.path.join(repo, git_root_dir, "HEAD")
    with open(head_path, "w") as f:
        print(branch, file=f)


def get_head(repo: str) -> str:
    branch = get_branch(repo)
    branch_path = os.path.join(repo, git_root_dir, "refs", "heads", branch)
    with open(branch_path, "r") as f:
        return f.read().strip()


def set_head(repo: str, sha: str):
    branch = get_branch(repo)
    branch_path = os.path.join(repo, git_root_dir, "refs", "heads", branch)
    with open(branch_path, "w") as f:
        print(sha, file=f)


def git_spawn_branch(repo: str, branch: str):
    head_sha = get_head(repo)
    branch_path = os.path.join(repo, git_root_dir, "refs", "heads", branch)
    with open(branch_path, "w") as f:
        print(head_sha, file=f)


def git_delete_branch(repo: str, branch: str):
    branch_path = os.path.join(repo, git_root_dir, "refs", "heads", branch)
    os.unlink(branch_path)


def git_list_branches(repo: str):
    heads = os.path.join(repo, git_root_dir, "refs", "heads")
    current_branch = os.path.basename(get_branch(repo))
    for b in os.listdir(heads):
        if b == current_branch:
            print(f"* {b}")
        else:
            print(b)


# git add


def git_add(repo: str, file: str):
    repo_path = os.path.realpath(repo)
    file_path = os.path.realpath(file)
    rel_path = file_path[len(repo_path) + 1 :]
    path = os.path.join(repo, git_root_dir, "index")
    assert os.path.exists(os.path.join(repo, rel_path))
    with open(path, "a") as f:
        print(rel_path, file=f)


def clear_index(repo: str):
    path = os.path.join(repo, git_root_dir, "index")
    with open(path, "w") as fi:
        fi.truncate()

# git commit


def parse_index(repo: str) -> Tree:
    head = get_head(repo)
    if head:
        tree = "TODO"
    else:
        tree = "TODO"
    path = os.path.join(repo, git_root_dir, "index")
    with open(path, "r") as f:
        for p in f.readlines():
            "TODO"
    return tree


def git_commit(repo: str, author: str, msg: str) -> str:
    pass


# git log


def git_log(repo: str):
    pass


# git checkout


def clear_repo(repo: str):
    for name in os.listdir(repo):
        if name != git_root_dir:
            path = os.path.join(repo, name)
            try:
                if os.path.isfile(path) or os.path.islink(path):
                    os.unlink(path)
                elif os.path.isdir(path):
                    shutil.rmtree(path)
            except Exception as e:
                print("Failed to delete %s. Reason: %s" % (path, e))


def tree_checkout(repo: str, tree: Dict[str, str], path: str):
    pass


def git_checkout_sha(repo: str, sha: str):
    pass


def git_checkout_branch(repo: str, branch: str):
    pass
