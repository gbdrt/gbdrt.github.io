from __future__ import annotations
from typing import *

import os
import shutil
import hashlib
from datetime import datetime

# git init

git_root_dir = ".minigit"


def git_init(repo: str):
    git_path = os.path.join(repo, git_root_dir)
    if not os.path.exists(git_path):
        os.mkdir(git_path)
        os.mkdir(os.path.join(git_path, "objects"))
        os.mkdir(os.path.join(git_path, "refs"))
        os.mkdir(os.path.join(git_path, "refs", "heads"))
        head_path = os.path.join(git_path, "refs", "heads", "main")
        with open(os.path.join(git_path, "HEAD"), "w") as f:
            print("main", file=f)
        with open(head_path, "w") as f:
            pass
        with open(os.path.join(git_path, "index"), "w"):
            pass


def find_repo() -> str:
    def _find(path):
        if git_root_dir in os.listdir(path):
            return path
        else:
            return _find(os.path.join(path, ".."))

    return _find(".")


# Blobs, trees, commits

## Blobs


def hash_object(repo: str, fmt: str, data: str) -> str:
    pass


def load_object(repo: str, sha: str) -> Dict[str, str]:
    pass


def load_blob(repo: str, sha: str) -> str:
    blob_obj = load_object(repo, sha)
    assert blob_obj["format"] == "blob"
    return blob_obj["data"]


## Objets git


def serialize_git_object(d: Dict[str, str]) -> str:
    pass


def deserialize_git_object(s: str) -> Dict[str, str]:
    pass


def load_git_object(repo: str, sha: str, format: str) -> Dict[str, str]:
    pass


## Tree


class Tree:
    pass


def tree_add_loc(tree: Tree, loc: List[str]):
    pass


def tree_from_sha(repo: str, name: str, sha: str) -> Tree:
    pass

def hash_tree(repo: str, index: Tree) -> str:
    pass


## Commits


def hash_commit(
    repo: str, author: str, msg: str, tree_sha: str, parent_sha: str
) -> str:
    pass


# git branch


def get_branch(repo: str) -> str:
    head_path = os.path.join(repo, git_root_dir, "HEAD")
    with open(head_path, "r") as f:
        return f.read().strip()


def set_branch(repo: str, branch: str):
    head_path = os.path.join(repo, git_root_dir, "HEAD")
    with open(head_path, "w") as f:
        print(branch, file=f)


def get_head(repo: str) -> str:
    branch = get_branch(repo)
    branch_path = os.path.join(repo, git_root_dir, "refs", "heads", branch)
    with open(branch_path, "r") as f:
        return f.read().strip()


def set_head(repo: str, sha: str):
    branch = get_branch(repo)
    branch_path = os.path.join(repo, git_root_dir, "refs", "heads", branch)
    with open(branch_path, "w") as f:
        print(sha, file=f)


def git_spawn_branch(repo: str, branch: str):
    head_sha = get_head(repo)
    branch_path = os.path.join(repo, git_root_dir, "refs", "heads", branch)
    with open(branch_path, "w") as f:
        print(head_sha, file=f)


def git_delete_branch(repo: str, branch: str):
    branch_path = os.path.join(repo, git_root_dir, "refs", "heads", branch)
    os.unlink(branch_path)


def git_list_branches(repo: str):
    heads = os.path.join(repo, git_root_dir, "refs", "heads")
    current_branch = os.path.basename(get_branch(repo))
    for b in os.listdir(heads):
        if b == current_branch:
            print(f"* {b}")
        else:
            print(b)


# git add


def git_add(repo: str, file: str):
    pass


def clear_index(repo: str):
    pass


# git commit


def parse_index(repo: str) -> Tree:
    pass


def git_commit(repo: str, author: str, msg: str) -> str:
    pass


# git log


def git_log(repo: str):
    pass


# git checkout


def clear_repo(repo: str):
    for name in os.listdir(repo):
        if name != git_root_dir:
            path = os.path.join(repo, name)
            try:
                if os.path.isfile(path) or os.path.islink(path):
                    os.unlink(path)
                elif os.path.isdir(path):
                    shutil.rmtree(path)
            except Exception as e:
                print("Failed to delete %s. Reason: %s" % (path, e))


def tree_checkout(repo: str, tree: Dict[str, str], path: str):
    pass


def git_checkout_sha(repo: str, sha: str):
    pass


def git_checkout_branch(repo: str, branch: str):
    pass
